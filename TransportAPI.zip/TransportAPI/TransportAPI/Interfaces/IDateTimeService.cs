﻿namespace TransportAPI.Interfaces;

public interface IDateTimeService
{
    string GetDateTimeNow();
}
